﻿using System.Reflection;
using R2API;
using RoR2;
using UnityEngine;

namespace CustomItem
{
    internal static class Assets
    {

        internal static GameObject AxinomancyPrefab;
        internal static ItemIndex AxinomancyItemIndex;

        private const string ModPrefix = "@CustomItem:";      
        private const string PrefabPath = ModPrefix + "Assets/Import/Axe/GoodAxePrefab.prefab";
        private const string IconPath = ModPrefix + "Assets/Import/Axe_Icon/AxeV2lmao.png";

        internal static ItemIndex Init()
        {
            // First registering your AssetBundle into the ResourcesAPI with a modPrefix that'll also be used for your prefab and icon paths
            // note that the string parameter of this GetManifestResourceStream call will change depending on
            // your namespace and file name
            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("CustomItem.axinomancyfinal"))
            {
                var bundle = AssetBundle.LoadFromStream(stream);
                var provider = new AssetBundleResourcesProvider(ModPrefix.TrimEnd(':'), bundle);
                ResourcesAPI.AddProvider(provider);

                AxinomancyPrefab = bundle.LoadAsset<GameObject>("Assets/Import/Axe/GoodAxePrefab.prefab");
            }

            AxinomancyAsLunarTierItem();

            AddLanguageTokens();
            return AxinomancyItemIndex;
        }

        private static void AxinomancyAsLunarTierItem()
        {
            var AxinomancyItemDef = new ItemDef
            {
                name = "Axinomancy", // its the internal name, no spaces, apostrophes and stuff like that
                tier = ItemTier.Lunar,
                pickupModelPath = PrefabPath,
                pickupIconPath = IconPath,
                nameToken = "Axinomancy_NAME", // stylised name
                pickupToken = "Axinomancy_PICKUP",
                descriptionToken = "Axinomancy_DESC",
                loreToken = "Axinomancy_LORE",
                /*
                tags = new[]
                {
                    ItemTag.Utility,
                    ItemTag.Damage
                }
                */
            };

            var itemDisplayRules = new ItemDisplayRule[1]; // keep this null if you don't want the item to show up on the survivor 3d model. You can also have multiple rules !
            itemDisplayRules[0].followerPrefab = AxinomancyPrefab; // the prefab that will show up on the survivor
            itemDisplayRules[0].childName = "Head"; // this will define the starting point for the position of the 3d model, you can see what are the differents name available in the prefab model of the survivors
            itemDisplayRules[0].localScale = new Vector3(5f, 5f, 5f); // scale the model
            itemDisplayRules[0].localAngles = new Vector3(0f, 0f, 0f); // rotate the model
            itemDisplayRules[0].localPos = new Vector3(0f, 0f, -1f); // position offset relative to the childName, here the survivor Chest


            var Axinomancy = new R2API.CustomItem(AxinomancyItemDef, itemDisplayRules);

            AxinomancyItemIndex = ItemAPI.Add(Axinomancy); // ItemAPI sends back the ItemIndex of your item
        }

        private static void AddLanguageTokens()
        {
            //The Name should be self explanatory
            R2API.AssetPlus.Languages.AddToken("Axinomancy_NAME", "Axinomancy");
            //The Pickup is the short text that appears when you first pick this up. This text should be short and to the point, nuimbers are generally ommited.
            R2API.AssetPlus.Languages.AddToken("Axinomancy_PICKUP", "All knockback is increased.");
            //The Description is where you put the actual numbers and give an advanced description.
            R2API.AssetPlus.Languages.AddToken("Axinomancy_DESC",
                "Increases all <style=cIsUtility>knockback</style> caused by damage to be increased by <style=cIsUtility>30%</style> <style=cStack>(130% to the power of total axinomancies on team).</style> Stacks up to 13 times.");
            //The Lore is, well, flavor. You can write pretty much whatever you want here.
            R2API.AssetPlus.Languages.AddToken("Axinomancy_LORE",
                "\u201CThough her forgotten relic, her tool of chaos, still remained.\u2026\"\r\n\r\n-The Evisceration of Kur-skan the Heretic, VII\r\n");
        }
    }
}
