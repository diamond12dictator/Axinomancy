﻿using BepInEx;
using BepInEx.Logging;
using R2API;
using R2API.AssetPlus;
using R2API.Utils;
using UnityEngine;
using RoR2;

namespace CustomItem
{
    [BepInDependency(R2API.R2API.PluginGUID)]
    [R2APISubmoduleDependency(nameof(AssetPlus), nameof(ItemAPI), nameof(ItemDropAPI), nameof(ResourcesAPI))]
    [BepInPlugin(ModGuid, ModName, ModVer)]
    public class AxinomancyItem : BaseUnityPlugin
    {
        private const string ModVer = "1.0.0";
        private const string ModName = "Axinomancy";
        public const string ModGuid = "Providence";
        GameObject player;
        Inventory inventory;
        GameObject playerBody;
        CharacterBody characterBody;
        TeamIndex teamIndex;
        ItemIndex itemIndex;
        internal new static ManualLogSource Logger; 

        public void Awake()
        {
            Logger = base.Logger;
            itemIndex = Assets.Init();
            On.RoR2.HealthComponent.TakeDamage += (orig, self, damageInfo) =>
            {
                if (player == null)
                {
                    player = GameObject.FindObjectOfType<PingerController>().gameObject;
                    inventory = player.GetComponent<Inventory>();
                    playerBody = player.GetComponent<CharacterMaster>().bodyPrefab.gameObject;
                    characterBody = playerBody.GetComponent<CharacterBody>();
                    teamIndex = player.GetComponent<CharacterMaster>().teamIndex;
                }
                int count = Util.GetItemCountForTeam(teamIndex, itemIndex, true);
                if (count > 0 && count < 13)
                {
                    damageInfo.force *= Mathf.Pow(1.3f, count);
                }
                else if (count >= 13)
                {
                    damageInfo.force *= Mathf.Pow(1.3f, 13);
                }
                orig(self, damageInfo);
            };
        } 
    }
}